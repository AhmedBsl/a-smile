import { Product } from './store';

export const SAMPLE_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Classic Hoodie',
    description: 'Premium streetwear hoodie with interlocking A logo',
    price: 89.99,
    image: 'https://images.unsplash.com/photo-1556821552-7f41c5d440db?w=500&h=600&fit=crop',
    category: 'Hoodies',
    stock: 50,
    color: 'Black',
    size: 'M',
  },
  {
    id: '2',
    name: 'Smile Tee',
    description: 'Signature scorpion-tail smile graphic tee',
    price: 39.99,
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&h=600&fit=crop',
    category: 'T-Shirts',
    stock: 120,
    color: 'Red',
    size: 'L',
  },
  {
    id: '3',
    name: 'Charcoal Cargo Pants',
    description: 'Premium cargo pants with utility pockets',
    price: 129.99,
    image: 'https://images.unsplash.com/photo-1542272604-787c62d465d1?w=500&h=600&fit=crop',
    category: 'Pants',
    stock: 45,
    color: 'Charcoal',
    size: 'M',
  },
  {
    id: '4',
    name: 'Smile Cap',
    description: 'Embroidered logo baseball cap',
    price: 34.99,
    image: 'https://images.unsplash.com/photo-1588345921523-c2dcdb7f1dcd?w=500&h=600&fit=crop',
    category: 'Accessories',
    stock: 200,
    color: 'Black',
    size: 'One Size',
  },
  {
    id: '5',
    name: 'Venom Jacket',
    description: 'Limited edition neon accent bomber jacket',
    price: 199.99,
    image: 'https://images.unsplash.com/photo-1551028719-00167b16ebc5?w=500&h=600&fit=crop',
    category: 'Jackets',
    stock: 20,
    color: 'Black with Neon',
    size: 'M',
  },
  {
    id: '6',
    name: 'Smile Backpack',
    description: 'Durable streetwear backpack with branded compartments',
    price: 79.99,
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=500&h=600&fit=crop',
    category: 'Bags',
    stock: 35,
    color: 'Black',
    size: 'One Size',
  },
];

export const WILAYAS = [
  { id: 'algiers', name: 'Algiers', communes: ['Algiers', 'Bab El Oued', 'Kouba', 'Ouled Fayet'] },
  { id: 'oran', name: 'Oran', communes: ['Oran', 'Sidi Lakhdar', 'El Mers', 'El Ançor'] },
  { id: 'constantine', name: 'Constantine', communes: ['Constantine', 'Ben Aknoun', 'Sidi Merouane', 'Ibn Ziad'] },
  { id: 'annaba', name: 'Annaba', communes: ['Annaba', 'El Bouni', 'Sidi Amir', 'Berrahal'] },
  { id: 'blida', name: 'Blida', communes: ['Blida', 'Larbaa', 'Mouzaia', 'Soumaa'] },
  { id: 'tlemcen', name: 'Tlemcen', communes: ['Tlemcen', 'Sabra', 'Sidi Medjahed', 'Mechera Sfa'] },
];

export const SMILE_LOGO = `
<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" fill="currentColor">
  <g>
    <!-- Interlocking A -->
    <path d="M 30 20 L 50 60 L 70 20 L 80 20 L 50 80 L 20 20 Z" opacity="0.8"/>
    <!-- Scorpion tail smile -->
    <path d="M 35 55 Q 50 75 65 55" stroke="currentColor" stroke-width="3" fill="none" stroke-linecap="round"/>
  </g>
</svg>
`;
