'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Header } from '@/components/header';
import { Hero } from '@/components/hero';
import { AnimatedBackground } from '@/components/animated-background';
import { useStore } from '@/lib/store';
import { SAMPLE_PRODUCTS } from '@/lib/sample-data';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { Lock } from 'lucide-react';

export default function Home() {
  const router = useRouter();
  const products = useStore((state) => state.products);
  const addProduct = useStore((state) => state.addProduct);

  // Initialize sample products on first load
  useEffect(() => {
    if (products.length === 0) {
      SAMPLE_PRODUCTS.forEach((product) => {
        addProduct(product);
      });
    }
  }, [products.length, addProduct]);

  return (
    <main className="bg-background min-h-screen relative">
      <AnimatedBackground />
      <Header />
      <Hero />

      {/* Featured Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="mb-16 text-center"
          >
            <h2 className="text-4xl md:text-5xl font-black text-foreground mb-4">
              Featured Collection
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Hand-picked pieces that define street style. Every item tells a story of confidence and culture.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, staggerChildren: 0.1 }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {products.slice(0, 6).map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Link href={`/product/${product.id}`}>
                  <div className="group cursor-pointer h-full">
                    <div className="relative overflow-hidden rounded-lg bg-muted aspect-square mb-4">
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />
                    </div>
                    <h3 className="font-bold text-lg text-foreground group-hover:text-primary transition-colors mb-2">
                      {product.name}
                    </h3>
                    <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                      {product.description}
                    </p>
                    <div className="flex items-center justify-between">
                      <span className="text-2xl font-black text-primary">
                        ${product.price}
                      </span>
                      <span className="text-xs font-bold text-accent bg-accent/10 px-3 py-1 rounded-full">
                        In Stock
                      </span>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="mt-12 text-center"
          >
            <Link href="/shop">
              <button className="bg-primary text-primary-foreground px-8 py-3 font-bold hover:shadow-lg hover:scale-105 transition-all duration-300 rounded-lg">
                View Full Shop
              </button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-secondary text-secondary-foreground py-12 border-t border-border relative">
        {/* Secret admin button - bottom left */}
        <motion.button
          onClick={() => router.push('/admin')}
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 0.4, scale: 1 }}
          whileHover={{ opacity: 1, scale: 1.2 }}
          className="absolute bottom-4 left-4 p-2 rounded-lg bg-primary/20 text-primary hover:bg-primary/40 transition-colors group"
          title="Admin Access"
        >
          <Lock className="w-4 h-4 group-hover:animate-spin" />
        </motion.button>

        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-bold text-lg mb-4">A.SMILE</h3>
              <p className="text-sm opacity-75">
                Premium Algerian streetwear celebrating culture and confidence.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4 text-sm uppercase">Shop</h4>
              <ul className="space-y-2 text-sm opacity-75">
                <li><Link href="/shop" className="hover:opacity-100 transition-opacity">All Products</Link></li>
                <li><Link href="/shop?category=hoodies" className="hover:opacity-100 transition-opacity">Hoodies</Link></li>
                <li><Link href="/shop?category=tshirts" className="hover:opacity-100 transition-opacity">T-Shirts</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4 text-sm uppercase">Support</h4>
              <ul className="space-y-2 text-sm opacity-75">
                <li><a href="#" className="hover:opacity-100 transition-opacity">Contact</a></li>
                <li><a href="#" className="hover:opacity-100 transition-opacity">Shipping</a></li>
                <li><a href="#" className="hover:opacity-100 transition-opacity">Returns</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4 text-sm uppercase">Legal</h4>
              <ul className="space-y-2 text-sm opacity-75">
                <li><a href="#" className="hover:opacity-100 transition-opacity">Privacy</a></li>
                <li><a href="#" className="hover:opacity-100 transition-opacity">Terms</a></li>
                <li><a href="#" className="hover:opacity-100 transition-opacity">Cookies</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-foreground/10 pt-8 text-center text-sm opacity-75">
            <p>&copy; 2026 A.SMILE. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </main>
  );
}
