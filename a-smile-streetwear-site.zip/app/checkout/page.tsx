'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Header } from '@/components/header';
import { useStore } from '@/lib/store';
import { WILAYAS } from '@/lib/sample-data';
import { motion } from 'framer-motion';
import { ArrowRight, Check } from 'lucide-react';

export default function CheckoutPage() {
  const router = useRouter();
  const cart = useStore((state) => state.cart);
  const createOrder = useStore((state) => state.createOrder);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    wilaya: '',
    commune: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const selectedWilaya = WILAYAS.find((w) => w.id === formData.wilaya);
  const communes = selectedWilaya?.communes || [];

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shipping = subtotal > 100 ? 0 : 15;
  const tax = subtotal * 0.1;
  const total = subtotal + shipping + tax;

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.firstName.trim()) newErrors.firstName = 'First name is required';
    if (!formData.lastName.trim()) newErrors.lastName = 'Last name is required';
    if (!formData.email.trim()) newErrors.email = 'Email is required';
    if (!/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = 'Email is invalid';
    if (!formData.phone.trim()) newErrors.phone = 'Phone is required';
    if (!formData.address.trim()) newErrors.address = 'Address is required';
    if (!formData.wilaya) newErrors.wilaya = 'Wilaya is required';
    if (!formData.commune) newErrors.commune = 'Commune is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) return;

    const orderId = `ORD-${Date.now()}`;
    const order = {
      id: orderId,
      items: cart,
      total,
      status: 'pending' as const,
      customerName: `${formData.firstName} ${formData.lastName}`,
      customerEmail: formData.email,
      customerPhone: formData.phone,
      address: formData.address,
      wilaya: formData.wilaya,
      commune: formData.commune,
      createdAt: new Date().toISOString(),
    };

    createOrder(order);
    setSubmitted(true);

    setTimeout(() => {
      router.push(`/order/${orderId}`);
    }, 2000);
  };

  if (cart.length === 0) {
    return (
      <main className="bg-background min-h-screen">
        <Header />
        <div className="container mx-auto px-4 py-12 text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">
            Your cart is empty
          </h1>
          <Link href="/shop" className="text-primary hover:underline font-bold">
            Continue shopping
          </Link>
        </div>
      </main>
    );
  }

  if (submitted) {
    return (
      <main className="bg-background min-h-screen">
        <Header />
        <div className="container mx-auto px-4 py-20 text-center">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5, type: 'spring' }}
            className="inline-flex mb-4"
          >
            <div className="w-20 h-20 bg-accent text-accent-foreground rounded-full flex items-center justify-center">
              <Check className="w-10 h-10" />
            </div>
          </motion.div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Order Placed!</h1>
          <p className="text-muted-foreground mb-6">
            Thank you for your order. Redirecting to order details...
          </p>
        </div>
      </main>
    );
  }

  return (
    <main className="bg-background min-h-screen">
      <Header />

      {/* Page Header */}
      <div className="border-b border-border bg-background">
        <div className="container mx-auto px-4 py-8">
          <motion.h1
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-3xl font-black text-foreground"
          >
            Checkout
          </motion.h1>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Checkout Form */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-2"
          >
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Personal Info */}
              <div>
                <h2 className="text-xl font-bold text-foreground mb-4">
                  Shipping Information
                </h2>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-sm font-bold text-foreground mb-2">
                      First Name
                    </label>
                    <input
                      type="text"
                      value={formData.firstName}
                      onChange={(e) =>
                        setFormData({ ...formData, firstName: e.target.value })
                      }
                      className={`w-full px-4 py-2 border rounded-lg bg-background text-foreground ${
                        errors.firstName ? 'border-destructive' : 'border-border'
                      }`}
                      placeholder="John"
                    />
                    {errors.firstName && (
                      <p className="text-xs text-destructive mt-1">{errors.firstName}</p>
                    )}
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-foreground mb-2">
                      Last Name
                    </label>
                    <input
                      type="text"
                      value={formData.lastName}
                      onChange={(e) =>
                        setFormData({ ...formData, lastName: e.target.value })
                      }
                      className={`w-full px-4 py-2 border rounded-lg bg-background text-foreground ${
                        errors.lastName ? 'border-destructive' : 'border-border'
                      }`}
                      placeholder="Doe"
                    />
                    {errors.lastName && (
                      <p className="text-xs text-destructive mt-1">{errors.lastName}</p>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-sm font-bold text-foreground mb-2">
                      Email
                    </label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) =>
                        setFormData({ ...formData, email: e.target.value })
                      }
                      className={`w-full px-4 py-2 border rounded-lg bg-background text-foreground ${
                        errors.email ? 'border-destructive' : 'border-border'
                      }`}
                      placeholder="john@example.com"
                    />
                    {errors.email && (
                      <p className="text-xs text-destructive mt-1">{errors.email}</p>
                    )}
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-foreground mb-2">
                      Phone
                    </label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) =>
                        setFormData({ ...formData, phone: e.target.value })
                      }
                      className={`w-full px-4 py-2 border rounded-lg bg-background text-foreground ${
                        errors.phone ? 'border-destructive' : 'border-border'
                      }`}
                      placeholder="+213 123 45 67 89"
                    />
                    {errors.phone && (
                      <p className="text-xs text-destructive mt-1">{errors.phone}</p>
                    )}
                  </div>
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-bold text-foreground mb-2">
                    Street Address
                  </label>
                  <input
                    type="text"
                    value={formData.address}
                    onChange={(e) =>
                      setFormData({ ...formData, address: e.target.value })
                    }
                    className={`w-full px-4 py-2 border rounded-lg bg-background text-foreground ${
                      errors.address ? 'border-destructive' : 'border-border'
                    }`}
                    placeholder="123 Main Street"
                  />
                  {errors.address && (
                    <p className="text-xs text-destructive mt-1">{errors.address}</p>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold text-foreground mb-2">
                      Wilaya (State)
                    </label>
                    <select
                      value={formData.wilaya}
                      onChange={(e) =>
                        setFormData({ ...formData, wilaya: e.target.value, commune: '' })
                      }
                      className={`w-full px-4 py-2 border rounded-lg bg-background text-foreground ${
                        errors.wilaya ? 'border-destructive' : 'border-border'
                      }`}
                    >
                      <option value="">Select Wilaya</option>
                      {WILAYAS.map((wilaya) => (
                        <option key={wilaya.id} value={wilaya.id}>
                          {wilaya.name}
                        </option>
                      ))}
                    </select>
                    {errors.wilaya && (
                      <p className="text-xs text-destructive mt-1">{errors.wilaya}</p>
                    )}
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-foreground mb-2">
                      Commune
                    </label>
                    <select
                      value={formData.commune}
                      onChange={(e) =>
                        setFormData({ ...formData, commune: e.target.value })
                      }
                      disabled={!formData.wilaya}
                      className={`w-full px-4 py-2 border rounded-lg bg-background text-foreground ${
                        errors.commune ? 'border-destructive' : 'border-border'
                      } ${!formData.wilaya ? 'opacity-50 cursor-not-allowed' : ''}`}
                    >
                      <option value="">Select Commune</option>
                      {communes.map((commune) => (
                        <option key={commune} value={commune}>
                          {commune}
                        </option>
                      ))}
                    </select>
                    {errors.commune && (
                      <p className="text-xs text-destructive mt-1">{errors.commune}</p>
                    )}
                  </div>
                </div>
              </div>

              {/* Submit Button */}
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                type="submit"
                className="w-full bg-primary text-primary-foreground py-4 font-bold text-lg rounded-lg flex items-center justify-center gap-2 hover:shadow-lg transition-all"
              >
                Complete Order
                <ArrowRight className="w-5 h-5" />
              </motion.button>
            </form>
          </motion.div>

          {/* Order Summary */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-1 sticky top-24 h-fit"
          >
            <div className="bg-card border border-border p-6 rounded-lg">
              <h2 className="font-bold text-xl text-foreground mb-6">Order Summary</h2>

              <div className="space-y-3 mb-6 pb-6 border-b border-border max-h-64 overflow-y-auto">
                {cart.map((item) => (
                  <div key={item.productId} className="flex justify-between text-sm">
                    <div>
                      <p className="text-foreground font-bold">{item.name}</p>
                      <p className="text-xs text-muted-foreground">Qty: {item.quantity}</p>
                    </div>
                    <p className="text-foreground font-bold">
                      ${(item.price * item.quantity).toFixed(2)}
                    </p>
                  </div>
                ))}
              </div>

              <div className="space-y-3 mb-6 pb-6 border-b border-border">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span className="text-foreground font-bold">
                    ${subtotal.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Shipping</span>
                  <span className="text-foreground font-bold">
                    {shipping === 0 ? (
                      <span className="text-accent">FREE</span>
                    ) : (
                      `$${shipping.toFixed(2)}`
                    )}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Tax (10%)</span>
                  <span className="text-foreground font-bold">
                    ${tax.toFixed(2)}
                  </span>
                </div>
              </div>

              <div className="flex justify-between items-center">
                <span className="font-bold text-foreground">Total</span>
                <span className="text-2xl font-black text-primary">
                  ${total.toFixed(2)}
                </span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </main>
  );
}
