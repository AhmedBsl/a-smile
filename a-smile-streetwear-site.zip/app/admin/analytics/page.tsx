'use client';

import { useStore } from '@/lib/store';
import { AdminSidebar } from '@/components/admin-sidebar';
import { motion } from 'framer-motion';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

export default function AdminAnalyticsPage() {
  const orders = useStore((state) => state.orders);
  const products = useStore((state) => state.products);

  // Calculate metrics
  const totalRevenue = orders.reduce((sum, o) => sum + o.total, 0);
  const totalOrders = orders.length;
  const avgOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;
  const totalProducts = products.length;
  const totalStock = products.reduce((sum, p) => sum + p.stock, 0);

  // Revenue by status
  const revenueByStatus = [
    { name: 'Pending', value: orders.filter((o) => o.status === 'pending').reduce((sum, o) => sum + o.total, 0) },
    { name: 'Processing', value: orders.filter((o) => o.status === 'processing').reduce((sum, o) => sum + o.total, 0) },
    { name: 'Shipped', value: orders.filter((o) => o.status === 'shipped').reduce((sum, o) => sum + o.total, 0) },
    { name: 'Delivered', value: orders.filter((o) => o.status === 'delivered').reduce((sum, o) => sum + o.total, 0) },
  ].filter((item) => item.value > 0);

  // Orders by day (mock data for last 7 days)
  const ordersData = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (6 - i));
    const dayOrders = orders.filter(
      (o) =>
        new Date(o.createdAt).toLocaleDateString() ===
        date.toLocaleDateString()
    );

    return {
      date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      orders: dayOrders.length,
      revenue: dayOrders.reduce((sum, o) => sum + o.total, 0),
    };
  });

  // Top products by stock
  const topProducts = products
    .sort((a, b) => b.stock - a.stock)
    .slice(0, 5)
    .map((p) => ({
      name: p.name,
      stock: p.stock,
      price: p.price,
    }));

  const COLORS = ['#dc143c', '#00ff41', '#2a2a2a', '#e5e0d8'];

  return (
    <div className="flex bg-background text-foreground min-h-screen">
      <AdminSidebar />

      <main className="flex-1">
        {/* Header */}
        <div className="border-b border-border bg-background sticky top-0 z-30">
          <div className="p-6">
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
              <h1 className="text-3xl font-black text-foreground">Analytics</h1>
              <p className="text-sm text-muted-foreground mt-1">
                Sales and performance metrics
              </p>
            </motion.div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* KPIs */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, staggerChildren: 0.1 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"
          >
            {[
              { label: 'Total Revenue', value: `$${totalRevenue.toFixed(2)}`, color: 'text-primary' },
              { label: 'Total Orders', value: totalOrders, color: 'text-blue-600' },
              { label: 'Avg Order Value', value: `$${avgOrderValue.toFixed(2)}`, color: 'text-green-600' },
              { label: 'Products', value: totalProducts, color: 'text-purple-600' },
            ].map((kpi, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-card border border-border p-6 rounded-lg"
              >
                <p className="text-sm text-muted-foreground mb-2">{kpi.label}</p>
                <p className={`text-2xl font-black ${kpi.color}`}>{kpi.value}</p>
              </motion.div>
            ))}
          </motion.div>

          {/* Charts */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-6"
          >
            {/* Orders Over Time */}
            <div className="bg-card border border-border p-6 rounded-lg">
              <h2 className="text-lg font-bold text-foreground mb-4">
                Orders & Revenue (Last 7 Days)
              </h2>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={ordersData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                  <XAxis stroke="var(--color-muted-foreground)" style={{ fontSize: '12px' }} dataKey="date" />
                  <YAxis stroke="var(--color-muted-foreground)" style={{ fontSize: '12px' }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'var(--color-card)',
                      border: '1px solid var(--color-border)',
                    }}
                  />
                  <Legend />
                  <Line type="monotone" dataKey="orders" stroke="#dc143c" strokeWidth={2} />
                  <Line type="monotone" dataKey="revenue" stroke="#00ff41" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Revenue by Status */}
            {revenueByStatus.length > 0 && (
              <div className="bg-card border border-border p-6 rounded-lg">
                <h2 className="text-lg font-bold text-foreground mb-4">
                  Revenue by Order Status
                </h2>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={revenueByStatus}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) =>
                        `${name}: $${value.toFixed(0)}`
                      }
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {revenueByStatus.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => `$${value.toFixed(2)}`} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}
          </motion.div>

          {/* Top Products */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="bg-card border border-border p-6 rounded-lg"
          >
            <h2 className="text-lg font-bold text-foreground mb-4">
              Top Products by Stock
            </h2>
            {topProducts.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">No products yet</p>
            ) : (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={topProducts}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                  <XAxis
                    stroke="var(--color-muted-foreground)"
                    style={{ fontSize: '12px' }}
                    dataKey="name"
                  />
                  <YAxis stroke="var(--color-muted-foreground)" style={{ fontSize: '12px' }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'var(--color-card)',
                      border: '1px solid var(--color-border)',
                    }}
                  />
                  <Legend />
                  <Bar dataKey="stock" fill="#dc143c" />
                  <Bar dataKey="price" fill="#00ff41" />
                </BarChart>
              </ResponsiveContainer>
            )}
          </motion.div>
        </div>
      </main>
    </div>
  );
}
