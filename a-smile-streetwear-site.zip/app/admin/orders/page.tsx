'use client';

import { useState } from 'react';
import { useStore } from '@/lib/store';
import { AdminSidebar } from '@/components/admin-sidebar';
import { motion } from 'framer-motion';
import { Eye, FileText, Download } from 'lucide-react';

export default function AdminOrdersPage() {
  const orders = useStore((state) => state.orders);
  const updateOrder = useStore((state) => state.updateOrder);
  const [selectedOrder, setSelectedOrder] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  const filteredOrders = orders.filter((order) => {
    const matchesSearch =
      order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customerEmail.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = !statusFilter || order.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const statuses = ['pending', 'processing', 'shipped', 'delivered'] as const;

  const selectedOrderData = orders.find((o) => o.id === selectedOrder);

  const handleStatusChange = (orderId: string, newStatus: typeof statuses[number]) => {
    updateOrder(orderId, newStatus);
  };

  return (
    <div className="flex bg-background text-foreground min-h-screen">
      <AdminSidebar />

      <main className="flex-1">
        {/* Header */}
        <div className="border-b border-border bg-background sticky top-0 z-30">
          <div className="p-6">
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
              <h1 className="text-3xl font-black text-foreground">Orders</h1>
              <p className="text-sm text-muted-foreground mt-1">
                Manage and track customer orders
              </p>
            </motion.div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Orders List */}
            <div className="lg:col-span-2">
              {/* Filters */}
              <div className="mb-6 space-y-4">
                <input
                  type="text"
                  placeholder="Search by order ID, customer name, or email..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full px-4 py-2 border border-border rounded-lg bg-card text-foreground placeholder-muted-foreground"
                />
                <div className="flex gap-2 overflow-x-auto pb-2">
                  <button
                    onClick={() => setStatusFilter('')}
                    className={`px-4 py-2 rounded-lg font-bold whitespace-nowrap transition-all ${
                      statusFilter === ''
                        ? 'bg-primary text-primary-foreground'
                        : 'border border-border text-foreground hover:bg-muted'
                    }`}
                  >
                    All Orders
                  </button>
                  {statuses.map((status) => (
                    <button
                      key={status}
                      onClick={() => setStatusFilter(status)}
                      className={`px-4 py-2 rounded-lg font-bold whitespace-nowrap transition-all capitalize ${
                        statusFilter === status
                          ? 'bg-primary text-primary-foreground'
                          : 'border border-border text-foreground hover:bg-muted'
                      }`}
                    >
                      {status}
                    </button>
                  ))}
                </div>
              </div>

              {/* Orders Grid */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.6 }}
                className="space-y-3"
              >
                {filteredOrders.length === 0 ? (
                  <div className="bg-card border border-border rounded-lg p-12 text-center">
                    <p className="text-muted-foreground">
                      {searchTerm || statusFilter
                        ? 'No orders found matching your filters'
                        : 'No orders yet'}
                    </p>
                  </div>
                ) : (
                  filteredOrders
                    .sort(
                      (a, b) =>
                        new Date(b.createdAt).getTime() -
                        new Date(a.createdAt).getTime()
                    )
                    .map((order) => (
                      <motion.div
                        key={order.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        onClick={() =>
                          setSelectedOrder(
                            selectedOrder === order.id ? null : order.id
                          )
                        }
                        className={`bg-card border cursor-pointer transition-all p-4 rounded-lg ${
                          selectedOrder === order.id
                            ? 'border-primary shadow-lg'
                            : 'border-border hover:border-primary/50'
                        }`}
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <p className="font-bold text-foreground">
                              {order.id}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {new Date(order.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                          <span className="text-2xl font-black text-primary">
                            ${order.total.toFixed(2)}
                          </span>
                        </div>

                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm font-bold text-foreground">
                              {order.customerName}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {order.items.length} item
                              {order.items.length !== 1 ? 's' : ''}
                            </p>
                          </div>
                          <select
                            value={order.status}
                            onChange={(e) => {
                              e.stopPropagation();
                              handleStatusChange(
                                order.id,
                                e.target.value as typeof statuses[number]
                              );
                            }}
                            className={`text-xs font-bold px-3 py-1 rounded border-0 capitalize ${
                              order.status === 'delivered'
                                ? 'bg-accent/20 text-accent'
                                : order.status === 'shipped'
                                ? 'bg-blue-500/20 text-blue-600'
                                : order.status === 'processing'
                                ? 'bg-yellow-500/20 text-yellow-600'
                                : 'bg-gray-500/20 text-gray-600'
                            }`}
                          >
                            {statuses.map((status) => (
                              <option key={status} value={status}>
                                {status}
                              </option>
                            ))}
                          </select>
                        </div>
                      </motion.div>
                    ))
                )}
              </motion.div>
            </div>

            {/* Order Details */}
            {selectedOrderData && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-card border border-border rounded-lg p-6 h-fit sticky top-24"
              >
                <h2 className="text-lg font-bold text-foreground mb-6">
                  Order Details
                </h2>

                {/* Customer Info */}
                <div className="mb-6 pb-6 border-b border-border">
                  <h3 className="text-xs font-bold uppercase text-muted-foreground mb-3">
                    Customer
                  </h3>
                  <p className="font-bold text-foreground mb-1">
                    {selectedOrderData.customerName}
                  </p>
                  <p className="text-sm text-muted-foreground mb-2">
                    {selectedOrderData.customerEmail}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {selectedOrderData.customerPhone}
                  </p>
                </div>

                {/* Shipping Address */}
                <div className="mb-6 pb-6 border-b border-border">
                  <h3 className="text-xs font-bold uppercase text-muted-foreground mb-3">
                    Shipping Address
                  </h3>
                  <p className="text-sm text-muted-foreground space-y-1">
                    <div>{selectedOrderData.address}</div>
                    <div>
                      {selectedOrderData.commune}, {selectedOrderData.wilaya}
                    </div>
                  </p>
                </div>

                {/* Items */}
                <div className="mb-6 pb-6 border-b border-border">
                  <h3 className="text-xs font-bold uppercase text-muted-foreground mb-3">
                    Items ({selectedOrderData.items.length})
                  </h3>
                  <div className="space-y-2">
                    {selectedOrderData.items.map((item) => (
                      <div
                        key={item.productId}
                        className="flex justify-between text-sm"
                      >
                        <div>
                          <p className="font-bold text-foreground">
                            {item.name}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            x{item.quantity}
                          </p>
                        </div>
                        <p className="font-bold text-foreground">
                          ${(item.price * item.quantity).toFixed(2)}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Total */}
                <div className="mb-6">
                  <p className="flex justify-between font-bold text-foreground">
                    <span>Total</span>
                    <span className="text-lg text-primary">
                      ${selectedOrderData.total.toFixed(2)}
                    </span>
                  </p>
                </div>

                {/* Actions */}
                <div className="space-y-2">
                  <button className="w-full bg-primary text-primary-foreground py-2 font-bold rounded-lg hover:shadow-lg transition-all flex items-center justify-center gap-2 text-sm">
                    <FileText className="w-4 h-4" />
                    Print Invoice
                  </button>
                  <button className="w-full border border-border text-foreground py-2 font-bold rounded-lg hover:bg-muted transition-all flex items-center justify-center gap-2 text-sm">
                    <Download className="w-4 h-4" />
                    Download
                  </button>
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
