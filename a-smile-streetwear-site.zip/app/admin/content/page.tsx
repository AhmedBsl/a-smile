'use client';

import { AdminSidebar } from '@/components/admin-sidebar';
import { motion } from 'framer-motion';
import { FileText, Image, Video } from 'lucide-react';

export default function AdminContentPage() {
  return (
    <div className="flex bg-background text-foreground min-h-screen">
      <AdminSidebar />

      <main className="flex-1">
        {/* Header */}
        <div className="border-b border-border bg-background sticky top-0 z-30">
          <div className="p-6">
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
              <h1 className="text-3xl font-black text-foreground">Content</h1>
              <p className="text-sm text-muted-foreground mt-1">
                Manage pages, images, and media
              </p>
            </motion.div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-6"
          >
            {[
              {
                icon: FileText,
                title: 'Pages',
                description: 'Edit website pages and content',
              },
              {
                icon: Image,
                title: 'Images',
                description: 'Manage product and media images',
              },
              {
                icon: Video,
                title: 'Videos',
                description: 'Upload and manage video content',
              },
            ].map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-card border border-border p-6 rounded-lg hover:shadow-lg transition-all cursor-pointer"
                >
                  <div className="w-12 h-12 bg-primary/10 text-primary rounded-lg flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="font-bold text-lg mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">
                    {feature.description}
                  </p>
                  <button className="mt-4 bg-primary text-primary-foreground px-4 py-2 rounded font-bold hover:shadow-lg transition-all text-sm">
                    Manage
                  </button>
                </motion.div>
              );
            })}
          </motion.div>

          {/* Coming Soon */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="mt-12 bg-card border-2 border-dashed border-primary/30 p-12 rounded-lg text-center"
          >
            <p className="text-muted-foreground mb-2">Content management</p>
            <p className="text-2xl font-bold text-foreground">
              Coming Soon
            </p>
            <p className="text-sm text-muted-foreground mt-4">
              CMS and content management tools are being prepared
            </p>
          </motion.div>
        </div>
      </main>
    </div>
  );
}
