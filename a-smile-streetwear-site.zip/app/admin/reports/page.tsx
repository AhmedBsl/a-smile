'use client';

import { useState } from 'react';
import { useStore } from '@/lib/store';
import { motion } from 'framer-motion';
import { Download, Filter, Calendar } from 'lucide-react';

export default function ReportsPage() {
  const orders = useStore((state) => state.orders);
  const products = useStore((state) => state.products);
  const [timeRange, setTimeRange] = useState<'week' | 'month' | 'all'>('month');

  const filteredOrders = orders.filter((order) => {
    if (timeRange === 'all') return true;
    const orderDate = new Date(order.createdAt);
    const now = new Date();
    const days = timeRange === 'week' ? 7 : 30;
    return (now.getTime() - orderDate.getTime()) / (1000 * 60 * 60 * 24) <= days;
  });

  const totalRevenue = filteredOrders.reduce((sum, o) => sum + o.total, 0);
  const totalOrders = filteredOrders.length;
  const avgOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;
  const totalItems = filteredOrders.reduce((sum, o) => sum + o.items.length, 0);

  // Calculate top selling products
  const productSales = new Map<string, { name: string; quantity: number; revenue: number }>();
  filteredOrders.forEach((order) => {
    order.items.forEach((item) => {
      const existing = productSales.get(item.productId) || { name: item.productId, quantity: 0, revenue: 0 };
      existing.quantity += item.quantity;
      existing.revenue += item.price * item.quantity;
      existing.name = item.name;
      productSales.set(item.productId, existing);
    });
  });

  const topProducts = Array.from(productSales.values())
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 10);

  const handleExportCSV = () => {
    const csv = [
      ['Order ID', 'Customer', 'Items', 'Total', 'Status', 'Date'],
      ...filteredOrders.map((o) => [
        o.id,
        o.customer.name,
        o.items.length,
        `$${o.total}`,
        o.status,
        new Date(o.createdAt).toLocaleDateString(),
      ]),
    ]
      .map((row) => row.join(','))
      .join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `orders-report-${new Date().toISOString()}.csv`;
    a.click();
  };

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="text-4xl font-black text-foreground mb-2">Reports</h1>
          <p className="text-muted-foreground">Sales and performance analytics</p>
        </motion.div>

        <motion.button
          onClick={handleExportCSV}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-lg font-bold"
        >
          <Download className="w-5 h-5" />
          Export CSV
        </motion.button>
      </div>

      {/* Time Range Filter */}
      <div className="flex gap-2 mb-8">
        {(['week', 'month', 'all'] as const).map((option) => (
          <motion.button
            key={option}
            onClick={() => setTimeRange(option)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-semibold capitalize transition-all ${
              timeRange === option
                ? 'bg-primary text-primary-foreground'
                : 'bg-muted text-foreground hover:bg-muted-foreground/20'
            }`}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Calendar className="w-4 h-4" />
            {option}
          </motion.button>
        ))}
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-card border border-border rounded-2xl p-6"
        >
          <p className="text-muted-foreground text-sm mb-1">Total Revenue</p>
          <p className="text-3xl font-black text-foreground">${totalRevenue.toLocaleString()}</p>
          <p className="text-xs text-muted-foreground mt-2">{filteredOrders.length} orders</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-card border border-border rounded-2xl p-6"
        >
          <p className="text-muted-foreground text-sm mb-1">Total Orders</p>
          <p className="text-3xl font-black text-foreground">{totalOrders}</p>
          <p className="text-xs text-muted-foreground mt-2">Last {timeRange === 'week' ? '7' : timeRange === 'month' ? '30' : 'all'} days</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-card border border-border rounded-2xl p-6"
        >
          <p className="text-muted-foreground text-sm mb-1">Avg Order Value</p>
          <p className="text-3xl font-black text-foreground">${avgOrderValue.toFixed(2)}</p>
          <p className="text-xs text-muted-foreground mt-2">Per transaction</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-card border border-border rounded-2xl p-6"
        >
          <p className="text-muted-foreground text-sm mb-1">Total Items Sold</p>
          <p className="text-3xl font-black text-foreground">{totalItems}</p>
          <p className="text-xs text-muted-foreground mt-2">Products shipped</p>
        </motion.div>
      </div>

      {/* Top Products */}
      <div className="bg-card border border-border rounded-2xl p-6 mb-8">
        <h2 className="text-2xl font-black text-foreground mb-6">Top Selling Products</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="border-b border-border">
              <tr>
                <th className="text-left px-4 py-3 font-bold text-foreground">Product</th>
                <th className="text-left px-4 py-3 font-bold text-foreground">Quantity</th>
                <th className="text-left px-4 py-3 font-bold text-foreground">Revenue</th>
                <th className="text-left px-4 py-3 font-bold text-foreground">% of Total</th>
              </tr>
            </thead>
            <tbody>
              {topProducts.map((product, index) => (
                <motion.tr
                  key={product.name}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-border hover:bg-muted/50 transition-colors"
                >
                  <td className="px-4 py-3 font-semibold text-foreground">{product.name}</td>
                  <td className="px-4 py-3 text-foreground">{product.quantity}</td>
                  <td className="px-4 py-3 font-bold text-primary">${product.revenue.toLocaleString()}</td>
                  <td className="px-4 py-3 text-foreground">{((product.revenue / totalRevenue) * 100).toFixed(1)}%</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recent Orders */}
      <div className="bg-card border border-border rounded-2xl overflow-hidden">
        <div className="p-6 border-b border-border">
          <h2 className="text-2xl font-black text-foreground">Recent Orders</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted border-b border-border">
              <tr>
                <th className="text-left px-6 py-4 font-bold text-foreground">Order ID</th>
                <th className="text-left px-6 py-4 font-bold text-foreground">Customer</th>
                <th className="text-left px-6 py-4 font-bold text-foreground">Items</th>
                <th className="text-left px-6 py-4 font-bold text-foreground">Total</th>
                <th className="text-left px-6 py-4 font-bold text-foreground">Status</th>
                <th className="text-left px-6 py-4 font-bold text-foreground">Date</th>
              </tr>
            </thead>
            <tbody>
              {filteredOrders.slice(0, 20).map((order, index) => (
                <motion.tr
                  key={order.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: index * 0.02 }}
                  className="border-b border-border hover:bg-muted/50 transition-colors"
                >
                  <td className="px-6 py-4 font-mono text-sm text-foreground">{order.id.slice(0, 8)}</td>
                  <td className="px-6 py-4 font-semibold text-foreground">{order.customer.name}</td>
                  <td className="px-6 py-4 text-foreground">{order.items.length}</td>
                  <td className="px-6 py-4 font-bold text-primary">${order.total.toLocaleString()}</td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                      order.status === 'delivered'
                        ? 'bg-green-500/20 text-green-600'
                        : order.status === 'shipped'
                        ? 'bg-blue-500/20 text-blue-600'
                        : order.status === 'pending'
                        ? 'bg-yellow-500/20 text-yellow-600'
                        : 'bg-red-500/20 text-red-600'
                    }`}>
                      {order.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-muted-foreground text-sm">{new Date(order.createdAt).toLocaleDateString()}</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
