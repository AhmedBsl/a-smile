'use client';

import { useState } from 'react';
import { useStore } from '@/lib/store';
import { motion } from 'framer-motion';
import { Users, TrendingUp, BarChart3, Star } from 'lucide-react';

export default function CustomersPage() {
  const orders = useStore((state) => state.orders);

  // Extract unique customers from orders
  const customers = Array.from(
    new Map(
      orders.map((order) => [
        order.customer.email,
        {
          email: order.customer.email,
          name: order.customer.name,
          phone: order.customer.phone,
          ordersCount: 0,
          totalSpent: 0,
          lastOrder: new Date(0),
          joinedDate: new Date(order.createdAt),
        },
      ])
    ).values()
  );

  // Calculate customer stats
  customers.forEach((customer) => {
    const customerOrders = orders.filter((o) => o.customer.email === customer.email);
    customer.ordersCount = customerOrders.length;
    customer.totalSpent = customerOrders.reduce((sum, o) => sum + o.total, 0);
    if (customerOrders.length > 0) {
      customer.lastOrder = new Date(customerOrders[customerOrders.length - 1].createdAt);
    }
  });

  const topCustomers = [...customers].sort((a, b) => b.totalSpent - a.totalSpent).slice(0, 5);
  const totalCustomers = customers.length;
  const totalRevenue = customers.reduce((sum, c) => sum + c.totalSpent, 0);
  const avgOrderValue = totalRevenue / orders.length || 0;
  const repeatCustomers = customers.filter((c) => c.ordersCount > 1).length;

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-4xl font-black text-foreground mb-2">Customers</h1>
        <p className="text-muted-foreground">Customer analytics and management</p>
      </motion.div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-card border border-border rounded-2xl p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm mb-1">Total Customers</p>
              <p className="text-3xl font-black text-foreground">{totalCustomers}</p>
            </div>
            <Users className="w-12 h-12 text-primary/20" />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-card border border-border rounded-2xl p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm mb-1">Total Revenue</p>
              <p className="text-3xl font-black text-foreground">${totalRevenue.toLocaleString()}</p>
            </div>
            <TrendingUp className="w-12 h-12 text-purple-500/20" />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-card border border-border rounded-2xl p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm mb-1">Avg Order Value</p>
              <p className="text-3xl font-black text-foreground">${avgOrderValue.toFixed(2)}</p>
            </div>
            <BarChart3 className="w-12 h-12 text-cyan-500/20" />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-card border border-border rounded-2xl p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm mb-1">Repeat Customers</p>
              <p className="text-3xl font-black text-foreground">{repeatCustomers}</p>
            </div>
            <Star className="w-12 h-12 text-yellow-500/20" />
          </div>
        </motion.div>
      </div>

      {/* Top Customers */}
      <div className="mb-8">
        <h2 className="text-2xl font-black text-foreground mb-4">Top Customers</h2>
        <div className="bg-card border border-border rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-muted border-b border-border">
                <tr>
                  <th className="text-left px-6 py-4 font-bold text-foreground">Name</th>
                  <th className="text-left px-6 py-4 font-bold text-foreground">Email</th>
                  <th className="text-left px-6 py-4 font-bold text-foreground">Orders</th>
                  <th className="text-left px-6 py-4 font-bold text-foreground">Total Spent</th>
                  <th className="text-left px-6 py-4 font-bold text-foreground">Last Order</th>
                </tr>
              </thead>
              <tbody>
                {topCustomers.map((customer, index) => (
                  <motion.tr
                    key={customer.email}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: index * 0.05 }}
                    className="border-b border-border hover:bg-muted/50 transition-colors"
                  >
                    <td className="px-6 py-4 font-semibold text-foreground">{customer.name}</td>
                    <td className="px-6 py-4 text-muted-foreground text-sm">{customer.email}</td>
                    <td className="px-6 py-4 font-bold text-foreground">{customer.ordersCount}</td>
                    <td className="px-6 py-4 font-bold text-primary">${customer.totalSpent.toLocaleString()}</td>
                    <td className="px-6 py-4 text-muted-foreground text-sm">
                      {customer.lastOrder.getTime() > 0 ? customer.lastOrder.toLocaleDateString() : 'No orders'}
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* All Customers */}
      <div>
        <h2 className="text-2xl font-black text-foreground mb-4">All Customers ({customers.length})</h2>
        <div className="bg-card border border-border rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-muted border-b border-border">
                <tr>
                  <th className="text-left px-6 py-4 font-bold text-foreground">Name</th>
                  <th className="text-left px-6 py-4 font-bold text-foreground">Email</th>
                  <th className="text-left px-6 py-4 font-bold text-foreground">Phone</th>
                  <th className="text-left px-6 py-4 font-bold text-foreground">Orders</th>
                  <th className="text-left px-6 py-4 font-bold text-foreground">Total Spent</th>
                  <th className="text-left px-6 py-4 font-bold text-foreground">Joined</th>
                </tr>
              </thead>
              <tbody>
                {customers.map((customer, index) => (
                  <motion.tr
                    key={customer.email}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: index * 0.02 }}
                    className="border-b border-border hover:bg-muted/50 transition-colors"
                  >
                    <td className="px-6 py-4 font-semibold text-foreground">{customer.name}</td>
                    <td className="px-6 py-4 text-muted-foreground text-sm">{customer.email}</td>
                    <td className="px-6 py-4 text-muted-foreground text-sm">{customer.phone}</td>
                    <td className="px-6 py-4 font-bold text-foreground">{customer.ordersCount}</td>
                    <td className="px-6 py-4 font-bold text-primary">${customer.totalSpent.toLocaleString()}</td>
                    <td className="px-6 py-4 text-muted-foreground text-sm">{customer.joinedDate.toLocaleDateString()}</td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
