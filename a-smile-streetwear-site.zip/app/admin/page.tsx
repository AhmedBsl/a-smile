'use client';

import { useStore } from '@/lib/store';
import { AdminSidebar } from '@/components/admin-sidebar';
import { motion } from 'framer-motion';
import { Package, ShoppingCart, TrendingUp, Users } from 'lucide-react';
import Link from 'next/link';

export default function AdminDashboard() {
  const products = useStore((state) => state.products);
  const orders = useStore((state) => state.orders);

  const stats = [
    {
      title: 'Total Products',
      value: products.length,
      icon: Package,
      color: 'bg-blue-500/10 text-blue-600',
      bgGradient: 'from-blue-500/20 to-cyan-500/20',
      href: '/admin/products',
    },
    {
      title: 'Total Orders',
      value: orders.length,
      icon: ShoppingCart,
      color: 'bg-green-500/10 text-green-600',
      bgGradient: 'from-purple-500/20 to-pink-500/20',
      href: '/admin/orders',
    },
    {
      title: 'Revenue',
      value: `$${orders.reduce((sum, o) => sum + o.total, 0).toFixed(2)}`,
      icon: TrendingUp,
      color: 'bg-primary/10 text-primary',
      bgGradient: 'from-yellow-500/20 to-orange-500/20',
      href: '/admin/reports',
    },
    {
      title: 'Active Status',
      value: 'Live',
      icon: Users,
      color: 'bg-accent/10 text-accent',
      bgGradient: 'from-cyan-500/20 to-teal-500/20',
      href: '/admin/settings',
    },
  ];

  const recentOrders = orders.slice(-5).reverse();
  const topProducts = products
    .sort((a, b) => b.stock - a.stock)
    .slice(0, 5);

  return (
    <div className="flex bg-background text-foreground min-h-screen">
      <AdminSidebar />

      <main className="flex-1 lg:ml-0">
        {/* Header */}
        <div className="border-b border-border bg-background sticky top-0 z-30">
          <div className="p-6">
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <h1 className="text-3xl font-black text-foreground">Dashboard</h1>
              <p className="text-sm text-muted-foreground mt-1">
                Welcome back! Here&apos;s your store overview.
              </p>
            </motion.div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-8">
          {/* Stats Grid */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, staggerChildren: 0.1 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"
          >
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Link href={stat.href}>
                    <div className={`relative bg-gradient-to-br ${stat.bgGradient} bg-card border border-border p-6 rounded-xl hover:shadow-lg transition-all cursor-pointer group overflow-hidden`}>
                      <div className="absolute inset-0 bg-card/80" />
                      <div className="relative z-10">
                        <div className="flex items-start justify-between mb-4">
                          <div className={`p-3 rounded-lg ${stat.color}`}>
                            <Icon className="w-6 h-6" />
                          </div>
                          <span className="text-2xl font-black text-primary">
                            {stat.value}
                          </span>
                        </div>
                        <p className="text-sm font-bold text-muted-foreground group-hover:text-foreground transition-colors">
                          {stat.title}
                        </p>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </motion.div>

          {/* Main Content Grid */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="grid grid-cols-1 lg:grid-cols-3 gap-6"
          >
            {/* Recent Orders */}
            <div className="lg:col-span-2 bg-card border border-border rounded-lg p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-foreground">Recent Orders</h2>
                <Link href="/admin/orders" className="text-sm text-primary hover:underline font-bold">
                  View All
                </Link>
              </div>

              {recentOrders.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  No orders yet
                </p>
              ) : (
                <div className="space-y-4">
                  {recentOrders.map((order) => (
                    <motion.div
                      key={order.id}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="flex items-center justify-between p-4 bg-background rounded-lg hover:bg-muted transition-colors"
                    >
                      <div>
                        <p className="font-bold text-foreground text-sm">
                          {order.id}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {order.customerName}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-primary">
                          ${order.total.toFixed(2)}
                        </p>
                        <p className={`text-xs font-bold capitalize ${
                          order.status === 'delivered'
                            ? 'text-accent'
                            : order.status === 'shipped'
                            ? 'text-blue-600'
                            : 'text-yellow-600'
                        }`}>
                          {order.status}
                        </p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>

            {/* Top Products */}
            <div className="bg-card border border-border rounded-lg p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-foreground">Top Products</h2>
                <Link href="/admin/products" className="text-sm text-primary hover:underline font-bold">
                  Manage
                </Link>
              </div>

              {topProducts.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  No products yet
                </p>
              ) : (
                <div className="space-y-3">
                  {topProducts.map((product, index) => (
                    <motion.div
                      key={product.id}
                      initial={{ opacity: 0, x: 10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="p-3 bg-background rounded-lg hover:bg-muted transition-colors"
                    >
                      <div className="flex items-start justify-between mb-2">
                        <p className="font-bold text-sm text-foreground line-clamp-1">
                          {product.name}
                        </p>
                        <span className="text-xs font-bold text-primary bg-primary/10 px-2 py-1 rounded">
                          ${product.price}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <p className="text-xs text-muted-foreground">
                          {product.stock} in stock
                        </p>
                        <div className="w-16 h-1 bg-primary/20 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-primary rounded-full"
                            style={{ width: `${Math.min(100, (product.stock / 100) * 100)}%` }}
                          />
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>

          {/* Quick Actions */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="bg-card border border-border rounded-lg p-6"
          >
            <h2 className="text-xl font-bold text-foreground mb-4">Quick Actions</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Link href="/admin/products">
                <button className="w-full bg-primary text-primary-foreground py-3 font-bold rounded-lg hover:shadow-lg transition-all">
                  Add Product
                </button>
              </Link>
              <Link href="/admin/orders">
                <button className="w-full border-2 border-primary text-primary py-3 font-bold rounded-lg hover:bg-primary hover:text-primary-foreground transition-all">
                  View Orders
                </button>
              </Link>
              <Link href="/admin/analytics">
                <button className="w-full border-2 border-border text-foreground py-3 font-bold rounded-lg hover:bg-muted transition-all">
                  View Analytics
                </button>
              </Link>
            </div>
          </motion.div>
        </div>
      </main>
    </div>
  );
}
