'use client';

import { AdminSidebar } from '@/components/admin-sidebar';
import { AdminLogin } from '@/components/admin-login';
import { useStore } from '@/lib/store';
import { useEffect, useState } from 'react';

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [mounted, setMounted] = useState(false);
  const adminAuth = useStore((state) => state.adminAuth);

  useEffect(() => {
    // Wait for hydration to complete
    setMounted(true);
  }, []);

  if (!mounted) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    );
  }

  if (!adminAuth) {
    return <AdminLogin />;
  }

  return (
    <div className="flex bg-background text-foreground min-h-screen">
      <AdminSidebar />
      <main className="flex-1 overflow-auto">
        {children}
      </main>
    </div>
  );
}
