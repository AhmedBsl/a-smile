'use client';

import { useState } from 'react';
import { AdminSidebar } from '@/components/admin-sidebar';
import { motion } from 'framer-motion';
import { useStore } from '@/lib/store';
import { Download, Upload, Bell, Lock, Zap, Globe } from 'lucide-react';

export default function AdminSettingsPage() {
  const backup = useStore((state) => state.backup);
  const restore = useStore((state) => state.restore);
  const [restoreMessage, setRestoreMessage] = useState('');
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [smsNotifications, setSmsNotifications] = useState(false);
  const [lowStockAlerts, setLowStockAlerts] = useState(true);
  const [orderNotifications, setOrderNotifications] = useState(true);

  const handleBackup = () => {
    const data = backup();
    const element = document.createElement('a');
    element.setAttribute(
      'href',
      'data:text/plain;charset=utf-8,' + encodeURIComponent(data)
    );
    element.setAttribute('download', `asmile-backup-${Date.now()}.json`);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (restore(content)) {
        setRestoreMessage('Data restored successfully!');
        setTimeout(() => setRestoreMessage(''), 3000);
      } else {
        setRestoreMessage('Failed to restore data. Invalid file.');
        setTimeout(() => setRestoreMessage(''), 3000);
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="flex bg-background text-foreground min-h-screen">
      <AdminSidebar />

      <main className="flex-1">
        {/* Header */}
        <div className="border-b border-border bg-background sticky top-0 z-30">
          <div className="p-6">
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
              <h1 className="text-3xl font-black text-foreground">Settings</h1>
              <p className="text-sm text-muted-foreground mt-1">
                Manage store settings and backups
              </p>
            </motion.div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 max-w-4xl">
          {/* Notifications Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 border border-border rounded-2xl p-6 mb-6"
          >
            <h2 className="text-2xl font-bold text-foreground mb-6 flex items-center gap-2">
              <Bell className="w-6 h-6 text-purple-500" />
              Notifications
            </h2>

            <div className="space-y-4">
              {[
                { label: 'Email Notifications', desc: 'Receive emails for orders', state: emailNotifications, setState: setEmailNotifications },
                { label: 'SMS Notifications', desc: 'Get SMS alerts for critical events', state: smsNotifications, setState: setSmsNotifications },
                { label: 'Low Stock Alerts', desc: 'Alert when products are running low', state: lowStockAlerts, setState: setLowStockAlerts },
                { label: 'Order Notifications', desc: 'Notify on new orders and updates', state: orderNotifications, setState: setOrderNotifications },
              ].map((notif, idx) => (
                <motion.div
                  key={idx}
                  className="flex items-center justify-between p-4 bg-card/50 rounded-xl hover:bg-card transition-colors"
                  whileHover={{ x: 4 }}
                >
                  <div>
                    <p className="font-bold text-foreground">{notif.label}</p>
                    <p className="text-sm text-muted-foreground">{notif.desc}</p>
                  </div>
                  <motion.button
                    onClick={() => notif.setState(!notif.state)}
                    className={`relative inline-flex h-7 w-12 items-center rounded-full transition-colors ${notif.state ? 'bg-primary' : 'bg-muted'}`}
                    whileHover={{ scale: 1.05 }}
                  >
                    <motion.span
                      className="inline-block h-5 w-5 transform rounded-full bg-white shadow-lg"
                      animate={{ x: notif.state ? 22 : 2 }}
                      transition={{ type: 'spring', stiffness: 300 }}
                    />
                  </motion.button>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Backup & Restore */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-border rounded-2xl p-6 mb-6"
          >
            <h2 className="text-2xl font-bold text-foreground mb-4 flex items-center gap-2">
              <Download className="w-6 h-6 text-cyan-500" />
              Data Backup & Restore
            </h2>
            <p className="text-sm text-muted-foreground mb-6">
              Backup your store data or restore from a previous backup.
            </p>

            <div className="space-y-4">
              {/* Backup Button */}
              <motion.button
                onClick={handleBackup}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full flex items-center justify-center gap-2 bg-primary text-primary-foreground py-3 font-bold rounded-xl hover:shadow-lg transition-all"
              >
                <Download className="w-5 h-5" />
                Download Backup
              </motion.button>

              {/* Restore Input */}
              <label className="w-full flex items-center justify-center gap-2 border-2 border-dashed border-border text-foreground py-3 font-bold rounded-xl hover:border-primary hover:bg-primary/5 transition-all cursor-pointer">
                <Upload className="w-5 h-5" />
                Restore from Backup
                <input
                  type="file"
                  accept=".json"
                  onChange={handleRestore}
                  className="hidden"
                />
              </label>

              {/* Message */}
              {restoreMessage && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`p-4 rounded-xl text-sm font-bold text-center ${
                    restoreMessage.includes('successfully')
                      ? 'bg-accent/20 text-accent'
                      : 'bg-destructive/20 text-destructive'
                  }`}
                >
                  {restoreMessage}
                </motion.div>
              )}
            </div>
          </motion.div>

          {/* Store Settings */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-gradient-to-br from-yellow-500/20 to-orange-500/20 border border-border rounded-2xl p-6 mb-6"
          >
            <h2 className="text-2xl font-bold text-foreground mb-4 flex items-center gap-2">
              <Globe className="w-6 h-6 text-yellow-500" />
              Store Information
            </h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-bold text-foreground mb-2">
                  Store Name
                </label>
                <input
                  type="text"
                  defaultValue="A.SMILE"
                  className="w-full px-4 py-2 border border-border rounded-lg bg-background text-foreground"
                  readOnly
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-foreground mb-2">
                  Store URL
                </label>
                <input
                  type="text"
                  defaultValue="asmile.vercel.app"
                  className="w-full px-4 py-2 border border-border rounded-lg bg-background text-foreground"
                  readOnly
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-foreground mb-2">
                  Currency
                </label>
                <select className="w-full px-4 py-2 border border-border rounded-lg bg-background text-foreground">
                  <option>USD ($)</option>
                  <option>DZD (DA)</option>
                  <option>EUR (€)</option>
                </select>
              </div>
            </div>
          </motion.div>

          {/* Security Settings */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-gradient-to-br from-red-500/20 to-pink-500/20 border border-border rounded-2xl p-6"
          >
            <h2 className="text-2xl font-bold text-foreground mb-4 flex items-center gap-2">
              <Lock className="w-6 h-6 text-red-600" />
              Security
            </h2>

            <div className="space-y-3">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full flex items-center justify-between px-4 py-3 bg-card/50 rounded-xl hover:bg-card transition-colors font-semibold"
              >
                <span>Change Password</span>
                <span className="text-muted-foreground">→</span>
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full flex items-center justify-between px-4 py-3 bg-card/50 rounded-xl hover:bg-card transition-colors font-semibold"
              >
                <span>Two-Factor Authentication</span>
                <span className="text-muted-foreground">→</span>
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full flex items-center justify-between px-4 py-3 bg-card/50 rounded-xl hover:bg-card transition-colors font-semibold"
              >
                <span>View Security Log</span>
                <span className="text-muted-foreground">→</span>
              </motion.button>
            </div>
          </motion.div>

          {/* Shipping Settings */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-gradient-to-br from-cyan-500/20 to-teal-500/20 border border-border rounded-2xl p-6 mt-6"
          >
            <h2 className="text-2xl font-bold text-foreground mb-4 flex items-center gap-2">
              <Zap className="w-6 h-6 text-cyan-500" />
              Store Performance
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-card/50 rounded-xl p-4 border border-green-500/30">
                <p className="text-sm text-muted-foreground mb-2">Status</p>
                <p className="text-2xl font-black text-green-600">Active</p>
                <p className="text-xs text-green-600 mt-2">Store is online</p>
              </div>

              <div className="bg-card/50 rounded-xl p-4 border border-blue-500/30">
                <p className="text-sm text-muted-foreground mb-2">Uptime</p>
                <p className="text-2xl font-black text-blue-600">99.9%</p>
                <p className="text-xs text-blue-600 mt-2">Last 30 days</p>
              </div>

              <div className="bg-card/50 rounded-xl p-4 border border-purple-500/30">
                <p className="text-sm text-muted-foreground mb-2">Performance</p>
                <p className="text-2xl font-black text-purple-600">Excellent</p>
                <p className="text-xs text-purple-600 mt-2">Load time: 0.8s</p>
              </div>
            </div>
          </motion.div>

          {/* Save Button */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="mt-8 flex gap-4"
          >
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="flex-1 bg-primary text-primary-foreground px-6 py-3 rounded-xl font-bold hover:shadow-lg transition-all"
            >
              Save Settings
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="flex-1 bg-muted text-foreground px-6 py-3 rounded-xl font-bold hover:bg-muted-foreground/20 transition-all"
            >
              Cancel
            </motion.button>
          </motion.div>
        </div>
      </main>
    </div>
  );
}
