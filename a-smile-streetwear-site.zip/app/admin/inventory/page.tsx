'use client';

import { useState } from 'react';
import { useStore } from '@/lib/store';
import { motion } from 'framer-motion';
import { Package, AlertTriangle, TrendingDown, BarChart3 } from 'lucide-react';

export default function InventoryPage() {
  const products = useStore((state) => state.products);
  const [sortBy, setSortBy] = useState<'stock' | 'price' | 'name'>('stock');

  const lowStockProducts = products.filter((p) => p.stock < 10);
  const outOfStockProducts = products.filter((p) => p.stock === 0);
  const totalValue = products.reduce((sum, p) => sum + p.price * p.stock, 0);
  const totalItems = products.reduce((sum, p) => sum + p.stock, 0);

  const sortedProducts = [...products].sort((a, b) => {
    if (sortBy === 'stock') return a.stock - b.stock;
    if (sortBy === 'price') return b.price - a.price;
    return a.name.localeCompare(b.name);
  });

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-4xl font-black text-foreground mb-2">Inventory</h1>
        <p className="text-muted-foreground">Manage your product stock levels</p>
      </motion.div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-card border border-border rounded-2xl p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm mb-1">Total Items</p>
              <p className="text-3xl font-black text-foreground">{totalItems}</p>
            </div>
            <Package className="w-12 h-12 text-primary/20" />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-card border border-border rounded-2xl p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm mb-1">Inventory Value</p>
              <p className="text-3xl font-black text-foreground">${totalValue.toLocaleString()}</p>
            </div>
            <BarChart3 className="w-12 h-12 text-purple-500/20" />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-card border border-border rounded-2xl p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm mb-1">Low Stock</p>
              <p className="text-3xl font-black text-yellow-500">{lowStockProducts.length}</p>
            </div>
            <AlertTriangle className="w-12 h-12 text-yellow-500/20" />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-card border border-border rounded-2xl p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm mb-1">Out of Stock</p>
              <p className="text-3xl font-black text-red-600">{outOfStockProducts.length}</p>
            </div>
            <TrendingDown className="w-12 h-12 text-red-600/20" />
          </div>
        </motion.div>
      </div>

      {/* Sort Controls */}
      <div className="mb-6 flex gap-2">
        {(['stock', 'price', 'name'] as const).map((option) => (
          <motion.button
            key={option}
            onClick={() => setSortBy(option)}
            className={`px-4 py-2 rounded-lg font-semibold capitalize transition-all ${
              sortBy === option
                ? 'bg-primary text-primary-foreground'
                : 'bg-muted text-foreground hover:bg-muted-foreground/20'
            }`}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {option}
          </motion.button>
        ))}
      </div>

      {/* Inventory Table */}
      <div className="bg-card border border-border rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted border-b border-border">
              <tr>
                <th className="text-left px-6 py-4 font-bold text-foreground">Product</th>
                <th className="text-left px-6 py-4 font-bold text-foreground">SKU</th>
                <th className="text-left px-6 py-4 font-bold text-foreground">Stock</th>
                <th className="text-left px-6 py-4 font-bold text-foreground">Price</th>
                <th className="text-left px-6 py-4 font-bold text-foreground">Total Value</th>
                <th className="text-left px-6 py-4 font-bold text-foreground">Status</th>
              </tr>
            </thead>
            <tbody>
              {sortedProducts.map((product, index) => (
                <motion.tr
                  key={product.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-border hover:bg-muted/50 transition-colors"
                >
                  <td className="px-6 py-4 font-semibold text-foreground">{product.name}</td>
                  <td className="px-6 py-4 text-muted-foreground">{product.id}</td>
                  <td className="px-6 py-4">
                    <span className="font-bold text-foreground">{product.stock}</span>
                  </td>
                  <td className="px-6 py-4 text-foreground">${product.price}</td>
                  <td className="px-6 py-4 font-semibold text-foreground">${(product.price * product.stock).toLocaleString()}</td>
                  <td className="px-6 py-4">
                    {product.stock === 0 ? (
                      <span className="px-3 py-1 bg-red-600/20 text-red-600 rounded-full text-sm font-bold">Out of Stock</span>
                    ) : product.stock < 10 ? (
                      <span className="px-3 py-1 bg-yellow-500/20 text-yellow-600 rounded-full text-sm font-bold">Low Stock</span>
                    ) : (
                      <span className="px-3 py-1 bg-green-500/20 text-green-600 rounded-full text-sm font-bold">In Stock</span>
                    )}
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
