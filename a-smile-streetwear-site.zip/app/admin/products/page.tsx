'use client';

import { useState } from 'react';
import { useStore } from '@/lib/store';
import { AdminSidebar } from '@/components/admin-sidebar';
import { motion } from 'framer-motion';
import { Plus, Edit2, Trash2, X, Check } from 'lucide-react';

export default function AdminProductsPage() {
  const products = useStore((state) => state.products);
  const addProduct = useStore((state) => state.addProduct);
  const updateProduct = useStore((state) => state.updateProduct);
  const deleteProduct = useStore((state) => state.deleteProduct);

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: 0,
    image: '',
    category: 'T-Shirts',
    stock: 0,
  });

  const filteredProducts = products.filter(
    (p) =>
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (editingId) {
      updateProduct(editingId, formData);
      setEditingId(null);
    } else {
      addProduct({
        id: `prod-${Date.now()}`,
        ...formData,
        size: 'M',
        color: 'Black',
      });
    }

    setFormData({
      name: '',
      description: '',
      price: 0,
      image: '',
      category: 'T-Shirts',
      stock: 0,
    });
    setShowForm(false);
  };

  const handleEdit = (product: any) => {
    setFormData({
      name: product.name,
      description: product.description,
      price: product.price,
      image: product.image,
      category: product.category,
      stock: product.stock,
    });
    setEditingId(product.id);
    setShowForm(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure? This action cannot be undone.')) {
      deleteProduct(id);
    }
  };

  const categories = Array.from(new Set(products.map((p) => p.category)));

  return (
    <div className="flex bg-background text-foreground min-h-screen">
      <AdminSidebar />

      <main className="flex-1">
        {/* Header */}
        <div className="border-b border-border bg-background sticky top-0 z-30">
          <div className="p-6 flex items-center justify-between">
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
              <h1 className="text-3xl font-black text-foreground">Products</h1>
              <p className="text-sm text-muted-foreground mt-1">
                Manage your product inventory
              </p>
            </motion.div>
            <button
              onClick={() => {
                setShowForm(!showForm);
                setEditingId(null);
                setFormData({
                  name: '',
                  description: '',
                  price: 0,
                  image: '',
                  category: 'T-Shirts',
                  stock: 0,
                });
              }}
              className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-lg font-bold hover:shadow-lg transition-all"
            >
              <Plus className="w-4 h-4" />
              Add Product
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {/* Form */}
          {showForm && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-card border border-border rounded-lg p-6 mb-6"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold">
                  {editingId ? 'Edit Product' : 'Add New Product'}
                </h2>
                <button
                  onClick={() => {
                    setShowForm(false);
                    setEditingId(null);
                  }}
                  className="p-2 hover:bg-muted rounded transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <input
                    type="text"
                    placeholder="Product Name"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    required
                    className="px-4 py-2 border border-border rounded bg-background text-foreground"
                  />
                  <select
                    value={formData.category}
                    onChange={(e) =>
                      setFormData({ ...formData, category: e.target.value })
                    }
                    className="px-4 py-2 border border-border rounded bg-background text-foreground"
                  >
                    <option>T-Shirts</option>
                    <option>Hoodies</option>
                    <option>Pants</option>
                    <option>Jackets</option>
                    <option>Accessories</option>
                    <option>Bags</option>
                  </select>
                </div>

                <textarea
                  placeholder="Description"
                  value={formData.description}
                  onChange={(e) =>
                    setFormData({ ...formData, description: e.target.value })
                  }
                  required
                  rows={3}
                  className="w-full px-4 py-2 border border-border rounded bg-background text-foreground"
                />

                <div className="grid grid-cols-3 gap-4">
                  <input
                    type="number"
                    placeholder="Price"
                    value={formData.price}
                    onChange={(e) =>
                      setFormData({ ...formData, price: parseFloat(e.target.value) })
                    }
                    required
                    className="px-4 py-2 border border-border rounded bg-background text-foreground"
                  />
                  <input
                    type="number"
                    placeholder="Stock"
                    value={formData.stock}
                    onChange={(e) =>
                      setFormData({ ...formData, stock: parseInt(e.target.value) })
                    }
                    required
                    className="px-4 py-2 border border-border rounded bg-background text-foreground"
                  />
                  <input
                    type="url"
                    placeholder="Image URL"
                    value={formData.image}
                    onChange={(e) =>
                      setFormData({ ...formData, image: e.target.value })
                    }
                    required
                    className="px-4 py-2 border border-border rounded bg-background text-foreground"
                  />
                </div>

                <div className="flex gap-4">
                  <button
                    type="submit"
                    className="flex-1 bg-primary text-primary-foreground py-2 font-bold rounded-lg hover:shadow-lg transition-all flex items-center justify-center gap-2"
                  >
                    <Check className="w-4 h-4" />
                    {editingId ? 'Update Product' : 'Add Product'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowForm(false)}
                    className="flex-1 border border-border text-foreground py-2 font-bold rounded-lg hover:bg-muted transition-all"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </motion.div>
          )}

          {/* Search */}
          <div className="mb-6">
            <input
              type="text"
              placeholder="Search products..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-4 py-2 border border-border rounded-lg bg-card text-foreground placeholder-muted-foreground"
            />
          </div>

          {/* Products Table */}
          <div className="overflow-x-auto">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6 }}
            >
              {filteredProducts.length === 0 ? (
                <div className="text-center py-12 bg-card border border-border rounded-lg">
                  <p className="text-muted-foreground">
                    {searchTerm ? 'No products found' : 'No products yet. Add one to get started!'}
                  </p>
                </div>
              ) : (
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left p-4 font-bold text-foreground">Name</th>
                      <th className="text-left p-4 font-bold text-foreground">Category</th>
                      <th className="text-left p-4 font-bold text-foreground">Price</th>
                      <th className="text-left p-4 font-bold text-foreground">Stock</th>
                      <th className="text-left p-4 font-bold text-foreground">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredProducts.map((product) => (
                      <motion.tr
                        key={product.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="border-b border-border hover:bg-muted transition-colors"
                      >
                        <td className="p-4">
                          <p className="font-bold text-foreground">{product.name}</p>
                        </td>
                        <td className="p-4">
                          <span className="text-sm bg-muted text-foreground px-3 py-1 rounded-full">
                            {product.category}
                          </span>
                        </td>
                        <td className="p-4 text-primary font-bold">
                          ${product.price}
                        </td>
                        <td className="p-4">
                          <span
                            className={`font-bold ${
                              product.stock > 0 ? 'text-accent' : 'text-destructive'
                            }`}
                          >
                            {product.stock}
                          </span>
                        </td>
                        <td className="p-4 flex gap-2">
                          <button
                            onClick={() => handleEdit(product)}
                            className="p-2 text-primary hover:bg-primary/10 rounded transition-colors"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDelete(product.id)}
                            className="p-2 text-destructive hover:bg-destructive/10 rounded transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              )}
            </motion.div>
          </div>
        </div>
      </main>
    </div>
  );
}
