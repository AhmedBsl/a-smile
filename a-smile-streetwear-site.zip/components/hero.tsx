'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

export function Hero() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8, ease: 'easeOut' },
    },
  };

  return (
    <section className="relative bg-background py-28 md:py-40 overflow-hidden">
      {/* Gradient background */}
      <div className="absolute inset-0 overflow-hidden -z-10">
        <div className="absolute top-20 right-1/3 w-80 h-80 bg-primary opacity-10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 -left-40 w-96 h-96 bg-accent opacity-5 rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-4">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="max-w-5xl"
        >
          {/* Tagline */}
          <motion.div variants={itemVariants} className="mb-8">
            <span className="inline-block text-xs font-black tracking-[0.2em] text-primary uppercase bg-primary/5 px-4 py-2 rounded-full border border-primary/20">
              ✦ A.SMILE — Algerian Streetwear
            </span>
          </motion.div>

          {/* Main Headline */}
          <motion.h1
            variants={itemVariants}
            className="text-6xl md:text-8xl font-black text-foreground mb-8 leading-[1.1] text-balance"
          >
            Street <br className="hidden sm:block" />
            <span className="relative">
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-accent to-primary">
                Confidence
              </span>
            </span>
          </motion.h1>

          {/* Description */}
          <motion.p
            variants={itemVariants}
            className="text-lg md:text-xl text-muted-foreground mb-12 max-w-2xl leading-relaxed font-light"
          >
            Premium streetwear celebrating Algerian culture. Bold design. Uncompromising quality. The confidence to stand out.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            variants={itemVariants}
            className="flex flex-col sm:flex-row gap-4"
          >
            <Link
              href="/shop"
              className="inline-flex items-center justify-center gap-3 bg-primary text-primary-foreground px-10 py-3 font-black text-lg hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 rounded-xl group"
            >
              Shop Now
              <ArrowRight className="w-5 h-5 group-hover:translate-x-2 transition-transform" />
            </Link>
            <Link
              href="#collection"
              className="inline-flex items-center justify-center gap-2 border-2 border-foreground text-foreground px-10 py-3 font-bold hover:bg-foreground hover:text-background transition-all duration-300 rounded-xl"
            >
              Discover More
            </Link>
          </motion.div>

          {/* Stats */}
          <motion.div
            variants={itemVariants}
            className="mt-20 grid grid-cols-3 gap-8 pt-12 border-t border-border"
          >
            <div>
              <div className="text-3xl font-bold text-primary">100%</div>
              <p className="text-sm text-muted-foreground mt-2">Premium Quality</p>
            </div>
            <div>
              <div className="text-3xl font-bold text-primary">Fast</div>
              <p className="text-sm text-muted-foreground mt-2">Local Shipping</p>
            </div>
            <div>
              <div className="text-3xl font-bold text-primary">Authentic</div>
              <p className="text-sm text-muted-foreground mt-2">Design Driven</p>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
