'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  Zap,
  FileText,
  Settings,
  BarChart3,
  LogOut,
  Menu,
  X,
  ChevronRight,
  Users,
  TrendingUp,
} from 'lucide-react';
import { useState } from 'react';
import { useStore } from '@/lib/store';

const menuItems = [
  { icon: LayoutDashboard, label: 'Dashboard', href: '/admin' },
  { icon: Package, label: 'Products', href: '/admin/products' },
  { icon: ShoppingCart, label: 'Orders', href: '/admin/orders' },
  { icon: BarChart3, label: 'Inventory', href: '/admin/inventory' },
  { icon: Users, label: 'Customers', href: '/admin/customers' },
  { icon: TrendingUp, label: 'Reports', href: '/admin/reports' },
  { icon: Zap, label: 'Analytics', href: '/admin/analytics' },
  { icon: Settings, label: 'Settings', href: '/admin/settings' },
];

export function AdminSidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const [isOpen, setIsOpen] = useState(false);
  const setAdminAuth = useStore((state) => state.setAdminAuth);

  const handleLogout = () => {
    setAdminAuth(false);
    router.push('/');
  };

  return (
    <>
      {/* Mobile Toggle */}
      <div className="lg:hidden fixed top-4 left-4 z-50">
        <motion.button
          onClick={() => setIsOpen(!isOpen)}
          className="p-2.5 bg-card border border-border rounded-xl hover:bg-muted transition-colors"
          whileTap={{ scale: 0.95 }}
        >
          <AnimatePresence mode="wait">
            {isOpen ? (
              <motion.div
                key="close"
                initial={{ rotate: -90 }}
                animate={{ rotate: 0 }}
                exit={{ rotate: 90 }}
              >
                <X className="w-5 h-5" />
              </motion.div>
            ) : (
              <motion.div
                key="menu"
                initial={{ rotate: 90 }}
                animate={{ rotate: 0 }}
                exit={{ rotate: -90 }}
              >
                <Menu className="w-5 h-5" />
              </motion.div>
            )}
          </AnimatePresence>
        </motion.button>
      </div>

      {/* Sidebar */}
      <motion.aside
        initial={{ x: -280 }}
        animate={{ x: isOpen ? 0 : -280 }}
        transition={{ duration: 0.3 }}
        className="lg:translate-x-0 fixed lg:static top-0 left-0 z-40 w-72 h-screen bg-card border-r border-border flex flex-col"
      >
        {/* Logo Section */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="p-6 border-b border-border"
        >
          <Link href="/admin" className="flex items-center gap-3 group">
            <motion.div
              className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center text-primary-foreground font-black text-lg group-hover:shadow-lg transition-all"
              whileHover={{ scale: 1.05 }}
            >
              A
            </motion.div>
            <div>
              <p className="font-black text-lg text-foreground">A.SMILE</p>
              <p className="text-xs font-semibold text-muted-foreground">ADMIN PANEL</p>
            </div>
          </Link>
        </motion.div>

        {/* Navigation */}
        <nav className="flex-1 p-4 overflow-y-auto">
          <div className="space-y-2">
            {menuItems.map((item, index) => {
              const Icon = item.icon;
              const isActive = pathname === item.href;

              return (
                <motion.div
                  key={item.href}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <Link href={item.href}>
                    <motion.button
                      onClick={() => setIsOpen(false)}
                      whileHover={{ x: 4 }}
                      whileTap={{ scale: 0.98 }}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-semibold transition-all duration-300 group ${
                        isActive
                          ? 'bg-gradient-to-r from-primary to-accent text-primary-foreground shadow-lg'
                          : 'text-foreground hover:bg-muted'
                      }`}
                    >
                      <Icon className={`w-5 h-5 ${isActive ? 'group-hover:scale-110' : ''} transition-transform`} />
                      <span className="flex-1 text-left">{item.label}</span>
                      {isActive && (
                        <motion.div
                          initial={{ x: -8, opacity: 0 }}
                          animate={{ x: 0, opacity: 1 }}
                        >
                          <ChevronRight className="w-4 h-4" />
                        </motion.div>
                      )}
                    </motion.button>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </nav>

        {/* Logout Button */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="p-4 border-t border-border"
        >
          <motion.button
            onClick={handleLogout}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl font-semibold text-foreground hover:bg-red-500/10 hover:text-red-600 transition-all duration-300 group"
          >
            <LogOut className="w-5 h-5 group-hover:rotate-180 transition-transform duration-300" />
            <span>Exit Admin</span>
          </motion.button>
        </motion.div>
      </motion.aside>

      {/* Mobile Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="lg:hidden fixed inset-0 bg-black/50 z-30"
            onClick={() => setIsOpen(false)}
          />
        )}
      </AnimatePresence>
    </>
  );
}
