'use client';

import { motion } from 'framer-motion';

export function ModernLogo({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) {
  const sizes = {
    sm: { box: 'w-8 h-8', text: 'text-lg' },
    md: { box: 'w-12 h-12', text: 'text-2xl' },
    lg: { box: 'w-16 h-16', text: 'text-4xl' },
  };

  return (
    <div className="relative">
      {/* Animated gradient background */}
      <motion.div
        className={`${sizes[size].box} relative rounded-xl bg-gradient-to-br from-primary via-purple-500 to-cyan-500 shadow-lg`}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        {/* Rotating inner ring */}
        <motion.div
          className="absolute inset-0 rounded-xl border-2 border-transparent bg-clip-padding"
          style={{
            borderImage: 'linear-gradient(45deg, #ff1a47, #9d4edd, #3a86ff, #06ffa5) 1',
          }}
          animate={{ rotate: 360 }}
          transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
        />

        {/* Central content */}
        <motion.div
          className={`${sizes[size].box} flex items-center justify-center relative z-10`}
          animate={{ y: [0, -2, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <motion.div
            className={`${sizes[size].text} font-black text-white drop-shadow-lg`}
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 2.5, repeat: Infinity }}
          >
            A
          </motion.div>
        </motion.div>

        {/* Pulsing glow effect */}
        <motion.div
          className={`${sizes[size].box} absolute inset-0 rounded-xl bg-gradient-to-r from-primary/30 to-cyan-500/30 blur-xl`}
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 3, repeat: Infinity }}
        />
      </motion.div>
    </div>
  );
}
